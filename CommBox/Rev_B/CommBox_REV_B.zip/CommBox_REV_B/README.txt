TR�KKPLAAT
----------

Kahepoolne, paksus 1 mm.


FAILID
------
CommBox_Schematic.pdf	-- skeem
CommBox_Layout.png	-- �ldjoonis
CommBox_TOP.pdf		-- �lemine pool
CommBox_BOTTOM.pdf	-- alumine pool, enne flood fill'i
COMMBOX.BOT		-- gerber: alumine pool
COMMBOX.TOP		-- gerber: �lemine pool
CommBox.gto		-- gerber: serv (ka augud tuleb v�lja l�igata)
COMMBOX.DRL		-- gerber: augud
CommBox.INF		-- gerber: puurid

OSTUNIMEKIRI
------------

Kogus	T�his	V��rtus	Korpus			Elfa kood

Takistid				
4	R1,R2,R4,R5 10k	1206			60-197-31
1	R3	100k	1206			60-199-70
				
Kondensaatorid				
2	C1,C2	0.1uF	1206			65-776-88
1	C3	6.8uF	3528			67-742-77
				
Mikroskeemid				
1	U1	ATMEGA8	QFP32			73-672-38
1	U2	LM9076	TO263-5			73-268-52
				
Transistorid				
1	Q1	STT3PF30L			71-131-60
1	Q2	PDTC144ET			71-303-88
1	Q3	IRF7416	SO8			71-159-59

Muud				
1	J13	CONN-CT6	CONN-CT6	43-856-47
1	X1	1.8432 MHz			74-500-34


KOOSTAMINE
----------

Ruum detailide jaoks:
�lemisel poolel 1.8 mm
Alumisel poolel 11 mm

Kvartsile X1 tuleb j�tta pikemad jalad ja panna
plaadi peale pikali.

Pesa J13 k�ib ATmega8-ga v�rreldes vastaspoolele. Orientatsioon
on m�rgitud failis CommBox_Layout.png

